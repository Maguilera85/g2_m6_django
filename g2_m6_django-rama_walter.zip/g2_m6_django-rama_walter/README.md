# g2_m6_django
Django acceso a bases de datos
